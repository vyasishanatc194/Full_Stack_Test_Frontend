import React, { useState } from 'react';
import { useRouter } from 'next/router';

import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input } from 'antd';

import { setCookie } from '@/utils';

import { ILoginData } from '@/types/global';


const LoginForm = () => {
  const [loginError,setLoginError] = useState<string>("")
  const router = useRouter();

  const onFinish: FormProps<ILoginData>['onFinish'] = async (values) => {
    const response = await fetch(process.env.NEXT_PUBLIC_BACKEND_URL +"/users/login/",{
      method:"POST",
      headers: {
          'Content-Type': 'application/json',
        },
      body: JSON.stringify(values)  
    })
    const data = await response.json();
    
    if(data.success){
      setCookie("__session",JSON.stringify(data.data),1)
      router.push("/dashboard")
    }
    else{
      setLoginError(data.message)
    }
      

  };


return(
    <>
        <Form
          name="basic"
          labelCol={{ span: 8 }}
          wrapperCol={{ span: 16 }}
          initialValues={{ remember: true }}
          onFinish={onFinish}
          autoComplete="off"
          className='login-form'
        >
          <Form.Item<ILoginData>
            label="Email"
            name="email"
            rules={[{ required: true, message: 'Please input your Email' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item<ILoginData>
            label="Password"
            name="password"
            rules={[{ required: true, message: 'Please input your password' }]}
          >
            <Input.Password autoComplete='off'/>
          </Form.Item>
          {loginError && <p className='error'>{loginError}</p>}
          <Form.Item wrapperCol={{ offset: 8 }}>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
            <a type="primary" href="/">
              Don't have an account?
            </a>
          </Form.Item>
        </Form>
    </>
  )
  
}

export default LoginForm;