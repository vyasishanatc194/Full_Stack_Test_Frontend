import React, { useState } from 'react';
import { useRouter } from 'next/router';

import { Form, Input, Button } from 'antd';

import { ISignUpData } from '@/types/global';


const SignUpForm = () => {
  const [signUpError,setSignUpError] = useState<string>("")
  const router = useRouter()

  const onSubmit =async (signUpValues:ISignUpData) => {
  const response = await fetch(process.env.NEXT_PUBLIC_BACKEND_URL +"/users/signup/",{
    method:"POST",
    headers: {
        'Content-Type': 'application/json',
      },
    body: JSON.stringify({'email':signUpValues.email,'first_name':signUpValues.firstName,'last_name':signUpValues.lastName,'password':signUpValues.password})  
  })
  const data = await response.json();
  if(data.response === 200){
    router.push("/dashboard")
  }
  else{
    setSignUpError(data.message)
  }
  };    

  return (
    <Form 
      onFinish={(onSubmit)} 
      layout="vertical" 
      autoComplete='off' 
      className='signup-form'
      initialValues={{ remember: false }}
    >
      <Form.Item<ISignUpData>
        label="First Name"
        name="firstName"
        rules={[{ required: true, message: '*First Name is Required' }]}
      >
        <Input />
      </Form.Item>
      <Form.Item<ISignUpData>
        label="Last Name"
        name="lastName"
        rules={[{ required: true, message: '*Last Name is Required' }]}
      >
        <Input />
      </Form.Item>
      <Form.Item<ISignUpData>
        label="Email"
        name="email"
        rules={[{ required: true, message: '*Email is Required' }]}
      >
        <Input />
      </Form.Item>

      <Form.Item<ISignUpData>
        label="Password"
        name="password"
        rules={[{ required: true, message: '*Password is Required' }]}
      >
        <Input.Password autoComplete='off'/>
      </Form.Item>
      {signUpError && <p className='error'>{signUpError}</p>}
      <Form.Item className='signup-form-button'>
        <Button type="primary" htmlType="submit">
          Sign Up
        </Button>
        <a type="primary" href='/login'>
          Already have an Account? Login
        </a>
      </Form.Item>
    </Form>
  );
};

export default SignUpForm;
