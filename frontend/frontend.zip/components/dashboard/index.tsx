import React,{useRef} from 'react'

import { Button,Input ,InputRef} from 'antd'

import { deleteCookie } from '@/utils'

const dashboard = () => {
    const inputRef = useRef<InputRef>(null)
  const handleLogout = () => {
    deleteCookie()
    window.location.reload()
  }
  const handleSearch = async(event:React.MouseEvent<HTMLElement>) => {

    const title =inputRef.current?.input?.value
    if(title){
        const response = await fetch(process.env.NEXT_PUBLIC_BACKEND_URL + `/jobs/posting/list/?job_title=${title}`,{
            method:"GET",
            headers: {
                'Content-Type': 'application/json',
                },
        })
        const responseData = await response.json()
        console.log(responseData)
    }
  }

  return (
    <>
    <div className='dashboard-container'>
      <div className='search-container'>
        <Input placeholder="Job Title" ref={inputRef}/>
        <Button type='primary' onClick={(e)=> handleSearch(e)}>Submit</Button>
      </div>
      <Button type='primary' onClick={()=> handleLogout()} danger>Logout</Button>
    </div>
    </>
  )
}

export default dashboard
