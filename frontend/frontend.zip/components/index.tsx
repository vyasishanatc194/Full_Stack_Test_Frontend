export { default as SignUpContent } from "./singup/Form"
export { default as LoginContent } from "./login/Form"
export {default as DashboardDesign} from "./dashboard/index"