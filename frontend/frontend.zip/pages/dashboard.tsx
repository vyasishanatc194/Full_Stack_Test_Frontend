import React from 'react'

import {DashboardDesign} from '@/components'

const Dashboard = () => {
  return (
    <div>
      <DashboardDesign/>
    </div>
  )
}

export default Dashboard
