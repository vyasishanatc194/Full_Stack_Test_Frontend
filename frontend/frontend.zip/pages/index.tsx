import React from 'react';
import {SignUpContent} from '@/components';

const index = () => {
  return (
    <SignUpContent/>
  );
};

export default index;
