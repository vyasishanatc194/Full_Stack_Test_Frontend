import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req:NextApiRequest,res:NextApiResponse){
    if(req.method === "POST"){
        const {firstName,lastName,email,password} = req.body
        console.log(firstName);
        console.log(lastName);
        console.log(email);
        console.log(password);
        
    }
}