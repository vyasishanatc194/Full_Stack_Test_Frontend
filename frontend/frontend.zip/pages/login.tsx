import React from 'react';
import {LoginContent} from '@/components';

const login = () => {
  return (
    <LoginContent/>
  );
};

export default login;
